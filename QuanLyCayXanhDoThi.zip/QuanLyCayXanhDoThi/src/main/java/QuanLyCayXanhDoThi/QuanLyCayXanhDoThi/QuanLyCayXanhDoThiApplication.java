package QuanLyCayXanhDoThi.QuanLyCayXanhDoThi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanLyCayXanhDoThiApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanLyCayXanhDoThiApplication.class, args);
	}

}
