package QuanLyCayXanhDoThi.QuanLyCayXanhDoThi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyCayXanhDoThiApplicationTests {

	@Test
	void contextLoads() {
	}

}
