package QuanLyCayXanh.QuanLyCayXanh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyCayXanhApplicationTests {

	@Test
	void contextLoads() {
	}

}
