package QuanLyCayXanh.QuanLyCayXanh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanLyCayXanhApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuanLyCayXanhApplication.class, args);
	}

}
